package main

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"cmsingbox.local/cmsingbox/internal/api"
	"cmsingbox.local/cmsingbox/internal/daemon"
	"cmsingbox.local/cmsingbox/internal/licensing"
	"cmsingbox.local/cmsingbox/internal/logger"
	"cmsingbox.local/cmsingbox/internal/storage"
)

var (
	Version               = "0.2.13"
	BuildTime             = "unknown"
	GitCommit             = "unknown"
	LicensePublicKey      = ""
	FreeSubscriptionLimit = "1"
	dataDir               string
	port                  int
)

func init() {
	// 获取默认数据目录
	homeDir, _ := os.UserHomeDir()
	defaultDataDir := filepath.Join(homeDir, ".cmsingbox")

	flag.StringVar(&dataDir, "data", defaultDataDir, "数据目录")
	flag.IntVar(&port, "port", 9090, "Web 服务端口")
}

func main() {
	flag.Parse()

	// 将 dataDir 转换为绝对路径，避免相对路径在子进程中出错
	var err error
	dataDir, err = filepath.Abs(dataDir)
	if err != nil {
		fmt.Fprintf(os.Stderr, "获取绝对路径失败: %v\n", err)
		os.Exit(1)
	}

	// 获取当前可执行文件的绝对路径（用于 launchd 安装）
	execPath, err := os.Executable()
	if err != nil {
		fmt.Fprintf(os.Stderr, "获取可执行文件路径失败: %v\n", err)
		os.Exit(1)
	}
	execPath, _ = filepath.EvalSymlinks(execPath)

	// 初始化日志系统
	if err := logger.InitLogManager(dataDir); err != nil {
		fmt.Fprintf(os.Stderr, "初始化日志系统失败: %v\n", err)
		os.Exit(1)
	}

	// 打印启动信息
	logger.Printf("CMSingBox v%s", Version)
	logger.Printf("数据目录: %s", dataDir)
	logger.Printf("Web 端口: %d", port)

	// 初始化存储
	store, err := storage.NewJSONStore(dataDir)
	if err != nil {
		logger.Printf("初始化存储失败: %v", err)
		os.Exit(1)
	}
	freeLimit, err := strconv.Atoi(FreeSubscriptionLimit)
	if err != nil || freeLimit < 0 {
		logger.Printf("免费订阅额度配置无效: %q", FreeSubscriptionLimit)
		os.Exit(1)
	}
	licensePublicKey := strings.TrimSpace(os.Getenv("CMSINGBOX_LICENSE_PUBLIC_KEY"))
	if licensePublicKey == "" {
		licensePublicKey = LicensePublicKey
	}
	licenseManager, err := licensing.NewManager(dataDir, licensePublicKey, freeLimit)
	if err != nil {
		logger.Printf("初始化授权模块失败: %v", err)
		os.Exit(1)
	}
	store.SetSubscriptionLimit(licenseManager.Limit())

	// 初始化进程管理器
	// sing-box 二进制文件路径固定为 dataDir/bin/sing-box
	singboxPath := filepath.Join(dataDir, "bin", "sing-box")
	configPath := filepath.Join(dataDir, "generated", "config.json")
	processManager := daemon.NewProcessManager(singboxPath, configPath, dataDir)

	// 初始化 launchd 管理器
	launchdManager, err := daemon.NewLaunchdManager()
	if err != nil {
		logger.Printf("初始化 launchd 管理器失败: %v", err)
	}

	// 初始化 systemd 管理器
	systemdManager, err := daemon.NewSystemdManager()
	if err != nil {
		logger.Printf("初始化 systemd 管理器失败: %v", err)
	}

	// 创建 API 服务器
	server := api.NewServer(store, processManager, launchdManager, systemdManager, execPath, port, Version, licenseManager)

	// 启动定时任务调度器
	server.StartScheduler()

	// 启动服务
	addr := fmt.Sprintf(":%d", port)
	logger.Printf("启动 Web 服务: http://0.0.0.0%s", addr)

	if err := server.Run(addr); err != nil {
		logger.Printf("启动服务失败: %v", err)
		os.Exit(1)
	}
}
